#include <stdio.h>


int main() {
    const char str[] = "555554";
    printf("%-5sTerminal",str);
}

